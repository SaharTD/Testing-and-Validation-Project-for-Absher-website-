// @ts-check
const { test, expect } = require('@playwright/test');

test('has title', async ({ page }) => {

  await page.goto('https://www.absher.sa/wps/portal/individuals/Home/homepublic/!ut/p/z1/hY6xDoIwEIafhYGVu5agxK041BgSI4vYxYApBVMoKRVe3yZOJBhv--__vsuBgBLEUM2dqlxnhkr7fBe7ByeEnSjHnPOC4vXISLxnGUlJArd_gPA1_hiG3hcbCMOsoFmMyC90E1jdOINQ2tTfd9lQx6kCYWUjrbTR2_p169w4HUIMcVmWSBmjtIyepg9xS2nN5KBckzD2Jb4SPecsCD5ltjEP/dz/d5/L0lDUmlTUSEhL3dHa0FKRnNBLzROV3FpQSEhL2Vu/');
  await page.getByPlaceholder('Username or ID Number').click();
  await page.getByPlaceholder('Username or ID Number').fill('111');
  await page.locator('i').first().click();
  await page.getByPlaceholder('Username or ID Number').click();
  await page.getByPlaceholder('Username or ID Number').click();
  await page.getByPlaceholder('Username or ID Number').click();
  await page.getByPlaceholder('Username or ID Number').press('Control+a');
  await page.getByPlaceholder('Username or ID Number').fill('1111111111'); //valid id
  await page.getByPlaceholder('Password').click();
  await page.getByPlaceholder('Password').press('CapsLock');
  await page.getByPlaceholder('Password').fill('S');
  await page.getByPlaceholder('Password').press('CapsLock');
  await page.getByPlaceholder('Password').fill('wb12345678');//valid password
  await page.getByRole('button', { name: 'Log in' }).click();

  await expect(page.getByText('Login to MOI E-services - Absher')).toBeVisible();


});
